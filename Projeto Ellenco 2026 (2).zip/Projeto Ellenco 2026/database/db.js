/**
 * ====================================================================
 * ELLENCO - GERENCIADOR DO BANCO DE DADOS RELACIONAL (SQLite)
 * Utiliza o módulo nativo node:sqlite do Node.js 22+
 * Inclui motor de análise e recuperação de contexto para o Agente IA
 * ====================================================================
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, 'ellenco.db');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');
const SEED_PATH = path.join(__dirname, 'seed.sql');

// Cria diretório se não existir
if (!fs.existsSync(__dirname)) {
    fs.mkdirSync(__dirname, { recursive: true });
}

// Inicializa conexão SQLite
const db = new DatabaseSync(DB_PATH);

// Configurações de performance e integridade
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

/**
 * Inicializa o esquema e a carga inicial caso o banco seja novo
 */
function initDatabase() {
    try {
        if (fs.existsSync(SCHEMA_PATH)) {
            const schemaSql = fs.readFileSync(SCHEMA_PATH, 'utf8');
            db.exec(schemaSql);
        }

        const row = db.prepare('SELECT COUNT(*) as total FROM apontamentos').get();
        if (row && row.total === 0 && fs.existsSync(SEED_PATH)) {
            console.log('🌱 Executando carga inicial de dados (Seed)...');
            const seedSql = fs.readFileSync(SEED_PATH, 'utf8');
            db.exec(seedSql);
            console.log('✅ Banco de dados populado com sucesso!');
        }
    } catch (err) {
        console.error('❌ Erro ao inicializar banco de dados:', err);
    }
}

initDatabase();

module.exports = {
    db,

    // ==========================================
    // USUÁRIOS & AUTENTICAÇÃO
    // ==========================================
    usuarios: {
        listar() {
            return db.prepare('SELECT id, nome, re, email, telefone, cargo, cargo_label, nivel, obra, status, aprovado_por, criado_em FROM usuarios ORDER BY id DESC').all();
        },
        buscarPorId(id) {
            return db.prepare('SELECT id, nome, re, email, telefone, cargo, cargo_label, nivel, obra, status, aprovado_por, criado_em FROM usuarios WHERE id = ?').get(id);
        },
        buscarPorREouEmail(termo) {
            return db.prepare('SELECT * FROM usuarios WHERE LOWER(re) = LOWER(?) OR LOWER(email) = LOWER(?)').get(termo, termo);
        },
        autenticar(termo, senha) {
            return db.prepare('SELECT id, nome, re, email, cargo, cargo_label, nivel, obra, status FROM usuarios WHERE (LOWER(re) = LOWER(?) OR LOWER(email) = LOWER(?)) AND senha = ?').get(termo, termo, senha);
        },
        cadastrar(dados) {
            const stmt = db.prepare(`
                INSERT INTO usuarios (nome, re, email, telefone, cargo, cargo_label, nivel, obra, status, senha)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            const res = stmt.run(
                dados.nome,
                dados.re,
                dados.email,
                dados.telefone || '',
                dados.cargo,
                dados.cargo_label,
                dados.nivel || 1,
                dados.obra || 'Matriz / Todas as Obras',
                dados.status || 'pendente',
                dados.senha
            );
            return { id: res.lastInsertRowid, ...dados };
        },
        atualizarStatus(id, status, aprovadoPor = '', motivo = '') {
            const stmt = db.prepare('UPDATE usuarios SET status = ?, aprovado_por = ?, motivo_rejeicao = ? WHERE id = ?');
            stmt.run(status, aprovadoPor, motivo, id);
            return this.buscarPorId(id);
        },
        remover(id) {
            return db.prepare('DELETE FROM usuarios WHERE id = ?').run(id);
        }
    },

    // ==========================================
    // APONTAMENTOS DE PRODUÇÃO (BDP)
    // ==========================================
    apontamentos: {
        listar(filtros = {}) {
            let sql = 'SELECT * FROM apontamentos WHERE 1=1';
            const params = [];

            if (filtros.obra && filtros.obra !== 'todas') {
                sql += ' AND obra = ?';
                params.push(filtros.obra);
            }
            if (filtros.equipe && filtros.equipe !== 'todas') {
                sql += ' AND equipe = ?';
                params.push(filtros.equipe);
            }
            if (filtros.dataInicio) {
                sql += ' AND data >= ?';
                params.push(filtros.dataInicio);
            }
            if (filtros.dataFim) {
                sql += ' AND data <= ?';
                params.push(filtros.dataFim);
            }

            sql += ' ORDER BY data DESC, id DESC';
            return db.prepare(sql).all(...params);
        },
        buscarPorId(id) {
            return db.prepare('SELECT * FROM apontamentos WHERE id = ?').get(id);
        },
        buscarSemantico(termo) {
            if (!termo || !termo.trim()) return [];
            
            // Palavras-chave relevantes (descartando preposições e palavras comuns)
            const stopWords = new Set(['qual', 'quais', 'quem', 'onde', 'como', 'quando', 'porque', 'por', 'que', 'com', 'para', 'pelo', 'pela', 'sobre', 'esse', 'essa', 'este', 'esta', 'isso', 'aquilo', 'foram', 'houve', 'aconteceu', 'relato', 'registrado', 'registrada', 'ocorreu', 'teve', 'esta', 'estao', 'estão', 'num', 'uma', 'uns', 'umas', 'dos', 'das', 'nas', 'nos']);
            const palavras = termo.toLowerCase()
                .replace(/[^a-zA-Z0-9áéíóúâêîôûãõç\s-]/g, ' ')
                .split(/\s+/)
                .filter(p => p.length >= 3 && !stopWords.has(p));

            if (palavras.length === 0) {
                const t = `%${termo.toLowerCase()}%`;
                return db.prepare(`
                    SELECT * FROM apontamentos 
                    WHERE LOWER(atividade) LIKE ? 
                       OR LOWER(parada) LIKE ? 
                       OR LOWER(obs) LIKE ? 
                       OR LOWER(obra) LIKE ? 
                       OR LOWER(equipe) LIKE ? 
                       OR LOWER(encarregado) LIKE ?
                       OR LOWER(protocolo) LIKE ?
                    ORDER BY data DESC, id DESC
                    LIMIT 15
                `).all(t, t, t, t, t, t, t);
            }

            // Constrói query dinâmica com as palavras relevantes
            const clausulas = palavras.map(() => `
                (LOWER(atividade) LIKE ? OR LOWER(parada) LIKE ? OR LOWER(obs) LIKE ? OR LOWER(obra) LIKE ? OR LOWER(equipe) LIKE ? OR LOWER(encarregado) LIKE ? OR LOWER(protocolo) LIKE ?)
            `).join(' OR ');

            const params = [];
            palavras.forEach(p => {
                const param = `%${p}%`;
                for (let i = 0; i < 7; i++) params.push(param);
            });

            return db.prepare(`
                SELECT * FROM apontamentos 
                WHERE ${clausulas}
                ORDER BY data DESC, id DESC
                LIMIT 15
            `).all(...params);
        },
        criar(dados) {
            const stmt = db.prepare(`
                INSERT INTO apontamentos 
                (protocolo, data, turno, obra, equipe, encarregado, atividade, unidade, planejado, realizado, horas, efetivo, desvio, eficiencia, produtividade, clima, parada, obs, status, assinado_por)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);

            const desvio = dados.planejado > 0 ? ((dados.realizado - dados.planejado) / dados.planejado) * 100 : 0;
            const eficiencia = dados.planejado > 0 ? (dados.realizado / dados.planejado) * 100 : 100;
            const produtividade = dados.horas > 0 ? (dados.realizado / dados.horas) : 0;
            const protocolo = dados.protocolo || `BDP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

            const res = stmt.run(
                protocolo,
                dados.data,
                dados.turno || 'Diurno',
                dados.obra,
                dados.equipe,
                dados.encarregado,
                dados.atividade,
                dados.unidade,
                dados.planejado,
                dados.realizado,
                dados.horas || 8.0,
                dados.efetivo || 10,
                parseFloat(desvio.toFixed(2)),
                parseFloat(eficiencia.toFixed(2)),
                parseFloat(produtividade.toFixed(1)),
                dados.clima || 'Ensolarado',
                dados.parada || 'Nenhum',
                dados.obs || '',
                dados.status || 'Concluído',
                dados.assinado_por || dados.encarregado
            );

            // Atualiza acumulados da equipe
            try {
                db.prepare(`
                    UPDATE equipes 
                    SET meta_acumulada = meta_acumulada + ?,
                        realizado_acumulado = realizado_acumulado + ?
                    WHERE nome = ?
                `).run(dados.planejado, dados.realizado, dados.equipe);
            } catch (e) {
                console.warn('Erro ao atualizar acumulados da equipe:', e.message);
            }

            return { id: res.lastInsertRowid, protocolo, ...dados, desvio, eficiencia, produtividade };
        },
        atualizar(id, dados) {
            const stmt = db.prepare(`
                UPDATE apontamentos SET 
                data = ?, turno = ?, obra = ?, equipe = ?, encarregado = ?, atividade = ?, 
                unidade = ?, planejado = ?, realizado = ?, horas = ?, efetivo = ?, 
                desvio = ?, eficiencia = ?, produtividade = ?, clima = ?, parada = ?, obs = ?, status = ?
                WHERE id = ?
            `);
            const desvio = dados.planejado > 0 ? ((dados.realizado - dados.planejado) / dados.planejado) * 100 : 0;
            const eficiencia = dados.planejado > 0 ? (dados.realizado / dados.planejado) * 100 : 100;
            const produtividade = dados.horas > 0 ? (dados.realizado / dados.horas) : 0;

            stmt.run(
                dados.data, dados.turno, dados.obra, dados.equipe, dados.encarregado, dados.atividade,
                dados.unidade, dados.planejado, dados.realizado, dados.horas, dados.efetivo,
                parseFloat(desvio.toFixed(2)), parseFloat(eficiencia.toFixed(2)), parseFloat(produtividade.toFixed(1)),
                dados.clima, dados.parada, dados.obs, dados.status, id
            );
            return this.buscarPorId(id);
        },
        remover(id) {
            return db.prepare('DELETE FROM apontamentos WHERE id = ?').run(id);
        },
        calcularKPIs(filtros = {}) {
            const lista = this.listar(filtros);
            let totalPlanejado = 0;
            let totalRealizado = 0;
            let totalHoras = 0;
            let acima = 0, naMeta = 0, abaixo = 0;

            lista.forEach(item => {
                totalPlanejado += (parseFloat(item.planejado) || 0);
                totalRealizado += (parseFloat(item.realizado) || 0);
                totalHoras += (parseFloat(item.horas) || 0);

                const ef = item.eficiencia || (item.planejado > 0 ? (item.realizado / item.planejado) * 100 : 100);
                if (ef >= 100) acima++;
                else if (ef >= 90) naMeta++;
                else abaixo++;
            });

            const desvioGeral = totalPlanejado > 0 ? ((totalRealizado - totalPlanejado) / totalPlanejado) * 100 : 0;
            const eficienciaGeral = totalPlanejado > 0 ? (totalRealizado / totalPlanejado) * 100 : 100;
            const produtividadeMedia = totalHoras > 0 ? (totalRealizado / totalHoras).toFixed(1) : '0.0';

            return {
                totalRegistros: lista.length,
                totalMeta: Math.round(totalPlanejado),
                totalRealizado: Math.round(totalRealizado),
                desvio: desvioGeral.toFixed(1),
                eficiencia: Math.round(eficienciaGeral),
                produtividadeMedia,
                totalHoras: totalHoras.toFixed(1),
                acima,
                naMeta,
                abaixo
            };
        }
    },

    // ==========================================
    // OBRAS E FRENTES DE SERVIÇO
    // ==========================================
    obras: {
        listar() {
            return db.prepare('SELECT * FROM obras ORDER BY id ASC').all();
        },
        buscarPorId(id) {
            return db.prepare('SELECT * FROM obras WHERE id = ?').get(id);
        },
        criar(dados) {
            const stmt = db.prepare('INSERT INTO obras (nome, local, eng, volume_total, progresso, status) VALUES (?, ?, ?, ?, ?, ?)');
            const res = stmt.run(dados.nome, dados.local, dados.eng, dados.volume_total || '10.000 un', dados.progresso || 0, dados.status || 'Em Andamento');
            return { id: res.lastInsertRowid, ...dados };
        },
        atualizar(id, dados) {
            const stmt = db.prepare('UPDATE obras SET nome = ?, local = ?, eng = ?, volume_total = ?, progresso = ?, status = ? WHERE id = ?');
            stmt.run(dados.nome, dados.local, dados.eng, dados.volume_total, dados.progresso, dados.status, id);
            return this.buscarPorId(id);
        },
        remover(id) {
            return db.prepare('DELETE FROM obras WHERE id = ?').run(id);
        }
    },

    // ==========================================
    // EQUIPES DE CAMPO
    // ==========================================
    equipes: {
        listar() {
            return db.prepare('SELECT * FROM equipes ORDER BY id ASC').all();
        },
        buscarPorId(id) {
            return db.prepare('SELECT * FROM equipes WHERE id = ?').get(id);
        },
        criar(dados) {
            const stmt = db.prepare('INSERT INTO equipes (nome, encarregado, atividade, obra, integrantes, meta_acumulada, realizado_acumulado, produtividade_media, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
            const res = stmt.run(
                dados.nome,
                dados.encarregado,
                dados.atividade,
                dados.obra || 'SP-270 Rodovia Raposo Tavares',
                dados.integrantes || 10,
                dados.meta_acumulada || 1000,
                dados.realizado_acumulado || 1000,
                dados.produtividade_media || '50.0 un/h',
                dados.status || 'Na Meta'
            );
            return { id: res.lastInsertRowid, ...dados };
        },
        atualizar(id, dados) {
            const stmt = db.prepare('UPDATE equipes SET nome = ?, encarregado = ?, atividade = ?, obra = ?, integrantes = ?, meta_acumulada = ?, realizado_acumulado = ?, produtividade_media = ?, status = ? WHERE id = ?');
            stmt.run(dados.nome, dados.encarregado, dados.atividade, dados.obra, dados.integrantes, dados.meta_acumulada, dados.realizado_acumulado, dados.produtividade_media, dados.status, id);
            return this.buscarPorId(id);
        },
        remover(id) {
            return db.prepare('DELETE FROM equipes WHERE id = ?').run(id);
        }
    },

    // ==========================================
    // EQUIPAMENTOS E FROTA
    // ==========================================
    equipamentos: {
        listar() {
            return db.prepare('SELECT * FROM equipamentos ORDER BY id ASC').all();
        },
        buscarPorId(id) {
            return db.prepare('SELECT * FROM equipamentos WHERE id = ?').get(id);
        },
        criar(dados) {
            const stmt = db.prepare('INSERT INTO equipamentos (codigo, tipo, modelo, horimetro, consumo_medio, local, status, ultima_manutencao) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            const res = stmt.run(dados.codigo, dados.tipo, dados.modelo, dados.horimetro || 0, dados.consumo_medio || '18 L/h', dados.local, dados.status || 'Operacional', dados.ultima_manutencao || 'Recente');
            return { id: res.lastInsertRowid, ...dados };
        },
        atualizar(id, dados) {
            const stmt = db.prepare('UPDATE equipamentos SET codigo = ?, tipo = ?, modelo = ?, horimetro = ?, consumo_medio = ?, local = ?, status = ?, ultima_manutencao = ? WHERE id = ?');
            stmt.run(dados.codigo, dados.tipo, dados.modelo, dados.horimetro, dados.consumo_medio, dados.local, dados.status, dados.ultima_manutencao, id);
            return this.buscarPorId(id);
        },
        remover(id) {
            return db.prepare('DELETE FROM equipamentos WHERE id = ?').run(id);
        }
    },

    // ==========================================
    // NOTIFICAÇÕES
    // ==========================================
    notificacoes: {
        listar() {
            return db.prepare('SELECT * FROM notificacoes ORDER BY id DESC LIMIT 20').all();
        },
        criar(titulo, mensagem, tipo = 'info') {
            const stmt = db.prepare('INSERT INTO notificacoes (titulo, mensagem, tipo) VALUES (?, ?, ?)');
            const res = stmt.run(titulo, mensagem, tipo);
            return { id: res.lastInsertRowid, titulo, mensagem, tipo };
        },
        marcarLida(id) {
            return db.prepare('UPDATE notificacoes SET lida = 1 WHERE id = ?').run(id);
        }
    },

    // ==========================================
    // MOTOR DE CONTEXTO E ANÁLISE PARA O AGENTE IA
    // ==========================================
    obterContextoParaIA(usuarioLogado = {}) {
        const kpis = this.apontamentos.calcularKPIs();
        const ultimosApontamentos = db.prepare('SELECT * FROM apontamentos ORDER BY data DESC, id DESC LIMIT 10').all();
        const todasObras = this.obras.listar();
        const todasEquipes = this.equipes.listar();
        const frota = this.equipamentos.listar();

        // Ocorrências / Paradas registradas
        const ocorrencias = db.prepare(`
            SELECT id, protocolo, data, obra, equipe, parada, obs, desvio 
            FROM apontamentos 
            WHERE (parada != 'Nenhum' AND parada IS NOT NULL AND parada != '') 
               OR (obs != '' AND obs IS NOT NULL)
               OR desvio < -10
            ORDER BY data DESC, id DESC 
            LIMIT 15
        `).all();

        // Resumo de frota
        const frotaOperacional = frota.filter(e => e.status === 'Operacional').length;
        const frotaManutencao = frota.filter(e => e.status === 'Em Manutenção');

        return {
            timestamp: new Date().toISOString(),
            usuario: {
                nome: usuarioLogado.nome || 'Colaborador',
                cargo: usuarioLogado.cargoLabel || usuarioLogado.cargo || 'Operacional',
                obra: usuarioLogado.obra || 'SP-270 Rodovia Raposo Tavares'
            },
            kpisGerais: kpis,
            ultimosApontamentos: ultimosApontamentos.map(a => ({
                id: a.id,
                protocolo: a.protocolo,
                data: a.data,
                turno: a.turno,
                obra: a.obra,
                equipe: a.equipe,
                encarregado: a.encarregado,
                atividade: a.atividade,
                planejado: `${a.planejado} ${a.unidade}`,
                realizado: `${a.realizado} ${a.unidade}`,
                desvioPercentual: `${a.desvio}%`,
                eficiencia: `${a.eficiencia}%`,
                produtividadeHora: `${a.produtividade} ${a.unidade}/h`,
                clima: a.clima,
                parada: a.parada,
                observacao: a.obs,
                status: a.status
            })),
            obras: todasObras.map(o => ({
                nome: o.nome,
                local: o.local,
                responsavel: o.eng,
                progresso: `${o.progresso}%`,
                volume: o.volume_total,
                status: o.status
            })),
            equipes: todasEquipes.map(e => ({
                nome: e.nome,
                lider: e.encarregado,
                atividade: e.atividade,
                obra: e.obra,
                integrantes: e.integrantes,
                metaAcumulada: e.meta_acumulada,
                realizadoAcumulado: e.realizado_acumulado,
                status: e.status
            })),
            frota: {
                total: frota.length,
                operando: frotaOperacional,
                emManutencao: frotaManutencao.map(m => `${m.codigo} (${m.tipo} - ${m.local})`)
            },
            ocorrenciasERecorrencias: ocorrencias.map(o => ({
                data: o.data,
                protocolo: o.protocolo,
                obra: o.obra,
                equipe: o.equipe,
                motivoParada: o.parada,
                detalhes: o.obs,
                desvio: `${o.desvio}%`
            }))
        };
    }
};
